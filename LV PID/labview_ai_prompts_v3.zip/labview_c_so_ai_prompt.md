# LabVIEW C / .so — AI Prompt Specification
## Call Library Function Node · NI Linux RT · cRIO Integration · v1.0

> **Purpose:** Paste any prompt in this document into **ChatGPT, Claude, Perplexity, Grok, Gemini,
> or any other mainstream LLM** to generate, debug, build, or extend any C shared library (.so)
> designed for the LabVIEW **Call Library Function Node (CLFN)** on NI Linux RT (CompactRIO).
> Replace all `[PLACEHOLDERS]` with your specifics before sending.
>
> **Works in:** Any AI chat interface — no special formatting required. All prompts are plain text.
>
> **v1.0 contents:**
> - Complete CLFN parameter-mapping rules (C types → LabVIEW types)
> - Function generation, audio synth, AI learning, and PID controller prompts
> - Cross-compilation guide (WSL + x86_64-linux-gnu-gcc, or native on cRIO)
> - Makefile and PowerShell build scripts
> - Smoke test pattern (`#ifdef SMOKE_TEST`) — **must pass before deploying to cRIO**
> - Parameter order lock policy — never reorder once a VI is released
> - Git/SVN workflow (optional)
> - Full CLFN error and wiring reference

---

## How to Use This Document

1. Find the prompt section that matches your task
2. Copy the entire code block
3. Replace all `[PLACEHOLDERS]` with your actual values
4. Paste into any mainstream LLM (ChatGPT, Claude, Perplexity, Grok, Gemini, etc.)
5. Compile and run the smoke test **before** deploying to cRIO or wiring into LabVIEW

> **LLM-Agnostic Note:** These prompts are plain-text C specifications. They work equally well
> with any chat AI that can write C99. Do not use LLM-specific plugins or features.
> The code produced must pass the standalone smoke test (`make test`) before it is
> deployed to the cRIO or wired into a LabVIEW CLFN.

---

## ⚠️ Critical Rules Before You Start

| Rule | Description |
|------|-------------|
| **Test first** | Every .c file MUST pass `make test` on the host before copying the .so to cRIO |
| **No parameter reordering** | Once a CLFN is wired into a released VI, **never change parameter order** without explicit approval and a new function name |
| **void return** | CLFN functions almost always return void; output data is written into caller-allocated arrays passed by pointer |
| **Caller allocates arrays** | LabVIEW pre-allocates output arrays with `Initialize Array`; C writes into that buffer — never malloc inside the exported function in a tight loop |
| **EXPORT macro required** | Use `__attribute__((visibility("default")))` on Linux RT; `__declspec(dllexport)` on Windows |
| **C calling convention** | Set Calling Convention = C in the CLFN dialog; never use C++ (no name mangling) |
| **No C++ headers** | Compile as C99 (`-std=c99`); do not `#include <iostream>` or use C++ features |
| **No dynamic memory in audio loops** | No `malloc`/`free` inside per-sample loops; all buffers allocated once by caller |
| **State in, state out** | No static mutable state that persists between LabVIEW calls except via explicit in/out arrays; static state inside a function is not thread-safe and survives VI restarts |

---

## Quick Copy Prompts

### 1. Generate a New CLFN-Compatible C Function

```
Write a C function for the LabVIEW Call Library Function Node (CLFN) with these requirements:

FUNCTION NAME: [your_function_name]  (lowercase with underscores, no C++ mangling)
PURPOSE: [what it computes, e.g., "generate a sine sweep waveform into a pre-allocated buffer"]
INPUTS (by value):
  [name]  [C type, e.g., double / int32_t / int32_t]  [units / range]
  ...
OUTPUT ARRAYS (by pointer — caller allocates):
  [name]  [C type]*  [e.g., double* out_array, pre-allocated to length_pts doubles]
  [name]  [C type]*  [e.g., int32_t* durs_out, pre-allocated to n_notes int32_t values]
RETURN TYPE: void  (no return value terminal in LabVIEW)
PHYSICS/LOGIC: [algorithm description]

Rules the function MUST follow:
1. Use only stdint.h, math.h, string.h — no stdlib malloc inside per-sample loops
2. Guard all pointer args: if (ptr == NULL || n <= 0) return;
3. Use the EXPORT macro:
   #ifdef _WIN32
     #define EXPORT __declspec(dllexport)
   #else
     #define EXPORT __attribute__((visibility("default")))
   #endif
4. Compile as C99 (-std=c99), position-independent code (-fPIC)
5. No C++ — no iostream, no new/delete, no templates
6. Include a smoke test under #ifdef [FUNCNAME]_SMOKE_TEST that:
   - Allocates output buffers with malloc
   - Calls the function with representative values
   - Checks peak amplitude or array values
   - Prints PASS/FAIL for each test case
   - Prints OVERALL: PASS or OVERALL: FAIL
   - Frees all buffers and returns 0 on pass, 1 on fail
7. The smoke test MUST compile and pass with:
   gcc -O2 -std=c99 -D[FUNCNAME]_SMOKE_TEST -o test_[funcname] [file].c -lm && ./test_[funcname]
   before the .so is deployed to cRIO or wired into LabVIEW

LabVIEW CLFN context:
- Target: NI Linux RT x86-64 (cRIO-904x series)
- Cross-compiler: x86_64-linux-gnu-gcc (from WSL or Linux host)
- LabVIEW: 2020+ with Call Library Function Node
- Calling convention: C (not stdcall, not C++)
- Scalar inputs: Pass by Value
- Array outputs: Pass as Array Data Pointer (pointer to first element)
  → LabVIEW pre-allocates with Initialize Array; CLFN writes into that buffer
- All scalar inputs must be wired — no defaults
```

---

### 2. Generate a Waveform Generator .so

> **Based on:** `waveform_gen.c` in the LV_Py_101 repository (commit `6bdf54c`).
> This is the minimal, proven pattern for a CLFN waveform function.

```
Write a C shared library for the LabVIEW CLFN that generates a [waveform type] into a
pre-allocated double array.

FUNCTION NAME: generate[waveform_name]  (e.g., generatewaveform, generatechirp)
TARGET: NI Linux RT x86-64 (cRIO-904x)

CLFN TERMINAL MAPPING (in order — DO NOT CHANGE once wired in LabVIEW):
  Parameter 1:  amp          double    Value    (peak amplitude, e.g., 0.0–2.0)
  Parameter 2:  freq_start   double    Value    (start frequency, Hz)
  Parameter 3:  freq_stop    double    Value    (stop frequency, Hz; == freq_start for fixed)
  Parameter 4:  dt           double    Value    (sample interval, e.g., 1/44100)
  Parameter 5:  length_pts   int32_t   Value    (number of samples to generate)
  Parameter 6:  out_array    double*   Pointer to Value  (pre-allocated by LabVIEW)

WAVEFORM ALGORITHM:
  [describe: fixed sine / chirp / square / etc.]
  Phase accumulation approach (NOT substitution):
    phase += 2 * M_PI * f_inst * dt;
    out_array[i] = amp * sin(phase);

RULES:
1. void return
2. Guard: if (length_pts <= 0 || out_array == NULL) return;
3. EXPORT macro as above
4. -std=c99, -fPIC, -shared
5. Smoke test under #ifdef WAVEFORM_SMOKE_TEST with 3 test cases:
   - Fixed frequency (freq_start == freq_stop)
   - Ascending sweep
   - Descending sweep
   Each test checks that peak amplitude > 0.5 * amp

LABVIEW CLFN CONFIGURATION:
  - Calling convention: C
  - Parameters 1–5: Numeric, Value (I32 for length_pts, DBL for others)
  - Parameter 6: Array Data Pointer (DBL *), Pass as Pointer to Value
  - Pre-allocate output with: Initialize Array [length_pts] → wire to Parameter 6
```

---

### 3. Generate a Piano / Instrument Tone Synthesizer .so

> **Based on:** `piano_synth.c` in the LV_Py_101 repository.
> Uses ADSR envelope + additive harmonics + inharmonicity model.

```
Write a C shared library for the LabVIEW CLFN that synthesizes a [instrument] tone.

FUNCTION NAME: render_note
TARGET: NI Linux RT x86-64

CLFN TERMINAL MAPPING (in order — frozen once released):
  Parameter 1:  freq         double    Value    (Hz, e.g., 261.63 for middle C)
  Parameter 2:  velocity     double    Value    (0.0–1.0)
  Parameter 3:  duration_s   double    Value    (note length in seconds)
  Parameter 4:  dt           double    Value    (1/sample_rate)
  Parameter 5:  out          double*   Pointer to Value  (pre-allocated, n_samples long)
  Parameter 6:  n_samples    int32_t   Value

SYNTHESIS MODEL:
  [describe: additive harmonics / FM / simple sine / piano (ADSR + inharmonicity) / etc.]
  For piano: 16 harmonics with HARMONIC_AMP[] weights, ADSR envelope (attack=0.5%,
  decay=8%, sustain=70%, release=15%), inharmonicity B=0.00015

SECOND FUNCTION: mix_notes (optional, include if mixing multiple tracks)
  Parameters: double* tracks (flat array n_tracks*n_samples), int32_t n_tracks,
              int32_t n_samples, double* out
  Purpose: sum all tracks, peak-normalize output to 0.92

RULES:
1. void return for both functions
2. NULL and size guards on all pointer params
3. No malloc inside synthesis loops — caller allocates all buffers
4. EXPORT macro
5. #ifdef PIANO_SMOKE_TEST: render C4 (261.63 Hz), check peak > 0.01; test mix_notes single track
6. Smoke test must pass before deploying to cRIO
```

---

### 4. Generate a Drum Synthesizer .so

> **Based on:** `drum_synth.c` in the LV_Py_101 repository.
> Uses physically-motivated synthesis (pitch sweep, filtered noise, ADSR) per drum type.

```
Write a C shared library for the LabVIEW CLFN that synthesizes drum hits.

FUNCTION NAME: render_drum_hit
TARGET: NI Linux RT x86-64

CLFN TERMINAL MAPPING (in order — frozen once released):
  Parameter 1:  drum_id      int32_t   Value    (0=kick,1=snare,2=hihat,3=tom-hi,
                                                  4=tom-mid,5=tom-lo,6=crash,7=ride)
  Parameter 2:  velocity     double    Value    (0.0–1.0)
  Parameter 3:  n_samples    int32_t   Value
  Parameter 4:  sample_rate  int32_t   Value    (e.g., 44100)
  Parameter 5:  out          double*   Pointer to Value  (pre-allocated n_samples doubles)

DRUM MODELS (physically-motivated):
  Kick:  pitched sine sweep (80→40 Hz over 80ms) + noise transient + exponential decay
  Snare: 190 Hz tone (60ms decay) + filtered white noise (120ms) + HP(600Hz)/LP(9000Hz)
  Hi-hat: white noise + HP(5000Hz)/LP(12000Hz) + very short decay
  Tom:   sine pitch sweep f0→f1 over 40ms + exponential decay (varies by tom)
  Crash: inharmonic partials (6 partials, ratios 1.0,1.48,1.72,2.0,2.55,3.15) + noise, long decay
  Ride:  same as crash but shorter decay (0.30s vs 0.80s)

HELPER REQUIREMENTS:
  - LCG pseudo-random number generator (not stdlib rand — avoids RT linking issues):
    static uint32_t lcg_state = 0x12345678u;
    static double lcg_rand(void) { lcg_state = lcg_state*1664525u+1013904223u;
      return ((double)(lcg_state>>1))/(double)0x7FFFFFFFu - 1.0; }
  - One-pole LP and HP filters (in-place, applied to full buffer after synthesis)
  - Exponential decay envelope: exp(-t / decay_s)
  - Normalize output to peak 0.95 after synthesis

SECOND FUNCTION: freq_to_drum_id
  Input: double freq
  Output: int32_t (0–7, nearest drum frequency match)
  Drum frequencies: {65.41, 82.41, 98.00, 123.47, 146.83, 174.61, 220.00, 261.63}
  Purpose: bridge from melody_learn output (MIDI Hz) to drum_id for this function

RULES:
1. void return for render_drum_hit; int32_t return for freq_to_drum_id
2. NULL and size guards
3. No malloc in per-sample loops
4. EXPORT macro on both functions
5. #ifdef DRUM_SMOKE_TEST: render all 8 drums, check peak in (0.01, 1.01); test freq_to_drum_id(82.41)=1; test NULL guard
6. Smoke test must pass standalone before deploying to cRIO
```

---

### 5. Generate a UCB1 Adaptive Melody Learner .so

> **Based on:** `melody_learn_v3.c` in the LV_Py_101 repository.
> This is the proven pattern for an AI learning loop that round-trips state through LabVIEW.

```
Write a C shared library for the LabVIEW CLFN that implements a UCB1 multi-armed bandit
adaptive melody and rhythm generator.

FUNCTION NAME: generate_melody_learn
TARGET: NI Linux RT x86-64

CLFN TERMINAL MAPPING (in order — frozen once released):
  Parameter 1:  n_notes           int32_t   Value
  Parameter 2:  sample_rate       int32_t   Value
  Parameter 3:  style             int32_t   Value    (0–5: lyrical/upbeat/mixed/jazz/rock/beat)
  Parameter 4:  like_dislike      int32_t   Value    (1=like, 0=dislike, -1=no feedback)
  Parameter 5:  last_arm_contour  int32_t   Value    (-1 on first call)
  Parameter 6:  last_arm_rhythm   int32_t   Value    (-1 on first call)
  Parameter 7:  coeffs_in         double*   Pointer to Value  (256 doubles, initialized to 0)
  Parameter 8:  freqs_out         double*   Pointer to Value  (pre-allocated n_notes doubles)
  Parameter 9:  durs_out          int32_t*  Pointer to Value  (pre-allocated n_notes int32_t)
  Parameter 10: coeffs_out        double*   Pointer to Value  (256 doubles output)
  Parameter 11: arm_contour_out   int32_t*  Pointer to Value  (selected contour arm)
  Parameter 12: arm_rhythm_out    int32_t*  Pointer to Value  (selected rhythm arm)

CONFIGURATION:
  N_ARMS = 8
  N_STYLES = 6
  COEFF_LEN = 256
  UCB_C = 1.5

COEFFICIENT LAYOUT (256 doubles):
  Indices 0–47:   CONT_REW[style][arm]  (contour arm rewards)
  Indices 48–95:  CONT_VIS[style][arm]  (contour arm visits)
  Indices 96–143: RHYT_REW[style][arm]  (rhythm arm rewards)
  Indices 144–191: RHYT_VIS[style][arm] (rhythm arm visits)
  Indices 192–255: reserved (initialize to 0)

  Access macros:
  #define CONT_REW(c,s,a) ((c)[(s)*N_ARMS+(a)])
  #define CONT_VIS(c,s,a) ((c)[48+(s)*N_ARMS+(a)])
  #define RHYT_REW(c,s,a) ((c)[96+(s)*N_ARMS+(a)])
  #define RHYT_VIS(c,s,a) ((c)[144+(s)*N_ARMS+(a)])

SCALES:
  C major (styles 0–2): CMAJ[8] = {60,62,64,65,67,69,71,72}
  C Dorian (style 3):   CDOR[8] = {60,62,63,65,67,69,70,72}
  A pentatonic (style 4): APEN[8] = {57,60,62,64,67,69,72,76}
  Drum MIDI (style 5):  DRUM[8] = {36,40,43,47,50,53,57,60}

UCB1 ALGORITHM:
  score(a) = mean_reward(a) + UCB_C * sqrt(log(total_visits) / visits(a))
  Unvisited arms are returned first in round-robin order
  After selecting arm: add +0.5 pending credit to its visit count
  Update previous arm with reward 1.0 if like_dislike > 0, else 0.0

RULES:
1. void return
2. NULL guards on all pointer params; n_notes > 0 guard
3. memcpy(coeffs_out, coeffs_in, COEFF_LEN * sizeof(double)) at start
4. EXPORT macro
5. Only stdint.h, math.h, string.h (no stdlib beyond for smoke test)
6. #ifdef LEARN_SMOKE_TEST: run all 6 styles, 3 rounds each with like=1; verify freqs > 30.0, durs > 100; PASS/FAIL
7. Smoke test must pass standalone before deploying to cRIO

LABVIEW INTEGRATION NOTES:
- Allocate coeffs_in (256 DBL) with Initialize Array at VI start, filled from CSV at startup
- Store coeffs_out in a shift register
- Store arm_contour_out, arm_rhythm_out in I32 shift registers
- On VI shutdown: save coeffs to CSV on cRIO filesystem (e.g., /home/lvuser/melody_coeffs.csv)
```

---

### 6. Generate a PID Controller .so for cRIO

> **Lesson learned:** For demo and educational purposes, wrapping a PID controller in a CLFN .so
> lets you test and prototype control logic outside LabVIEW, then swap it in via CLFN without
> changing the VI structure. The Python TCP auto-tuner can update Kp/Ki/Kd at runtime.

```
Write a C shared library for the LabVIEW CLFN that implements a discrete-time PID controller.

FUNCTION NAME: pid_step
TARGET: NI Linux RT x86-64

CLFN TERMINAL MAPPING (in order — frozen once released):
  Parameter 1:  setpoint     double    Value    (desired process variable)
  Parameter 2:  pv           double    Value    (measured process variable)
  Parameter 3:  kp           double    Value    (proportional gain)
  Parameter 4:  ki           double    Value    (integral gain)
  Parameter 5:  kd           double    Value    (derivative gain)
  Parameter 6:  dt           double    Value    (sample interval, seconds)
  Parameter 7:  out_min      double    Value    (output clamp minimum, e.g., 0.0)
  Parameter 8:  out_max      double    Value    (output clamp maximum, e.g., 100.0)
  Parameter 9:  integrator   double*   Pointer to Value  (integrator state in/out, 1 element)
  Parameter 10: prev_error   double*   Pointer to Value  (previous error in/out, 1 element)
  Parameter 11: u_out        double*   Pointer to Value  (control output, 1 element)

ALGORITHM:
  error = setpoint - pv
  P = kp * error
  integrator += ki * error * dt           // anti-windup: clamp integrator to [out_min, out_max]
  integrator  = clamp(integrator, out_min, out_max)
  D = kd * (error - prev_error) / dt      // derivative on error (not pv, to handle setpoint steps)
  u = P + integrator + D
  u_out = clamp(u, out_min, out_max)
  prev_error = error

RULES:
1. void return
2. NULL guards on pointer params
3. Anti-windup: clamp integrator to [out_min, out_max]
4. EXPORT macro
5. -std=c99, -fPIC
6. #ifdef PID_SMOKE_TEST:
   - Step test: setpoint=50, pv starts at 0, simulate 100 steps with dt=0.1, Kp=1.0, Ki=0.1, Kd=0.0
   - Verify u_out starts positive, error decreases over time, output stays in [out_min, out_max]
   - PASS if after 100 steps pv_simulated is within 10% of setpoint (use simple integrating plant)
7. Smoke test must pass standalone before deploying to cRIO

LABVIEW INTEGRATION:
- integrator and prev_error: use Initialize Array [1] → DBL scalar shift register (1-element array)
  OR use two DBL shift registers (single-element Pointer to Value)
- Update gains at runtime by wiring Kp/Ki/Kd from front panel controls (no VI restart needed)
- The Python TCP auto-tuner sends new Kp/Ki/Kd values; apply them on the next CLFN call
```

---

### 7. Debug a CLFN Error

```
My LabVIEW Call Library Function Node is throwing:
  [paste the LabVIEW error description, e.g., "Error 1097: Shared library failed to load"]

MY C FILE ([filename].c):
[PASTE YOUR ENTIRE C FILE HERE]

CLFN CONFIGURATION:
- Library path: [e.g., /home/lvuser/waveform_gen.so]
- Function name: [e.g., generatewaveform]
- Calling convention: [C / stdcall]
- Number of parameters configured: [e.g., 6]
- Parameter types configured (in order):
    1. [type, pass by]
    2. [type, pass by]
    ...

PLATFORM:
- Target: [NI Linux RT x86-64 / Windows 64-bit]
- Cross-compiler used: [e.g., x86_64-linux-gnu-gcc in WSL]
- Build command: [paste your gcc command or make output]

Please diagnose and fix. Apply these rules:
1. EXPORT macro must be present: __attribute__((visibility("default"))) on Linux
2. Calling convention: C (no C++ mangling)
3. Array outputs: passed as pointer (Array Data Pointer in CLFN), LabVIEW pre-allocates
4. NULL guards on all pointer params
5. Compile as -std=c99 -fPIC -shared
6. Confirm smoke test passes standalone before rewiring in LabVIEW
7. Never change parameter order without creating a new function name
```

---

### 8. Write a Makefile for NI Linux RT Cross-Compilation

> **Based on:** `Makefile` and `scripts/build_rt_sos.ps1` in the LV_Py_101 repository.

```
Write a Makefile and optional PowerShell build script for cross-compiling C source files
into .so shared libraries for NI Linux RT (x86-64) from a Windows host using WSL.

SOURCES (one .so per .c file):
  [list: e.g., waveform_gen.c, piano_synth.c, drum_synth.c, melody_learn_v3.c, pid_step.c]

CROSS-COMPILER: x86_64-linux-gnu-gcc  (in WSL; install with apt install gcc-x86-64-linux-gnu)
CFLAGS: -O2 -fPIC -Wall -Wextra -std=c99 -D_GNU_SOURCE
LDFLAGS: -shared -lm

Makefile requirements:
1. Default target 'all' builds all .so files
2. Target 'test' builds each .c with its SMOKE_TEST define and runs the test binary
   Example: gcc -O2 -DWAVEFORM_SMOKE_TEST -o waveform_gen_test waveform_gen.c -lm && ./waveform_gen_test
3. Target 'clean' removes all .so and test binaries
4. Use pattern rules if multiple .so files share the same build pattern
5. Print "Built [target] for NI Linux RT (x86-64)" after each .so

PowerShell script requirements (scripts/build_rt_sos.ps1):
1. Parameters: $RepoRoot (default path), $Compiler (default "wsl x86_64-linux-gnu-gcc"),
   -GitCommit switch, $CommitMessage
2. Build each .so from c/ source directory into rt-so/ output directory
3. Create rt-so/ if it does not exist
4. Error on non-zero exit code from compiler
5. Optional: git add rt-so/*.so + git commit + git push if -GitCommit is set
6. Print "Done." on success

DEPLOYMENT NOTES:
- Copy .so files to cRIO with FTP or SFTP: sftp admin@[crio-ip]
- Default cRIO deployment path: /home/lvuser/natinst/bin/ or /home/lvuser/
- CLFN library path in LabVIEW must match the deployed path exactly
- After copying, restart the LabVIEW RT engine if the .so was previously loaded
```

---

### 9. Port a Python LabVIEW Node Function to C CLFN

```
Convert this Python function (designed for the LabVIEW Python Node) to C for use as a
LabVIEW Call Library Function Node (.so) on NI Linux RT.

PYTHON FUNCTION:
[PASTE YOUR PYTHON FUNCTION HERE]

PYTHON → C TYPE MAPPING:
  float (Python)       → double (C)
  int (Python)         → int32_t (C)
  str (Python)         → NOT directly supported; pass as int32_t enum index instead
  list[float] (Python) → double* (C) with int32_t length parameter, pass as Array Data Pointer
  tuple (Python)       → separate out parameters (each as pointer)

CLFN TERMINAL MAPPING RULES:
  - Python return value → C output pointer parameter(s) at end of parameter list
  - Python list[float] input → (double* array, int32_t length) pair of C parameters
  - Python list[float] output → double* out_array (caller pre-allocates with Initialize Array)
  - Python str input → int32_t enum_id (add a lookup table in C)

REQUIREMENTS:
1. Maintain identical numerical behaviour within float64 precision
2. void return (all outputs via pointer parameters)
3. NULL guards
4. EXPORT macro
5. No malloc in per-sample loops
6. Include __FUNCNAME__SMOKE_TEST section comparing output to known Python results (≥ 3 cases)
7. Smoke test must pass standalone
8. Note any Python numpy functions that map to C math.h equivalents

PARAMETER ORDER NOTE:
  The Python function's parameter order defines the C CLFN terminal order.
  Once released, this order is FROZEN.
  If the Python version's parameter order changed after release, DO NOT propagate that
  change to the C version without creating a new function name.
```

---

### 10. Generate Documentation for a CLFN Library

```
I have a C shared library for the LabVIEW CLFN:

FUNCTION NAME: [name]
LIBRARY FILE: [e.g., /home/lvuser/waveform_gen.so]
PARAMETERS (in CLFN order):
  1. [name, C type, pass-by, description]
  2. ...
PURPOSE: [what the function does]

Write:
1. A CLFN README section (plain Markdown) with:
   - Full parameter table (name, C type, LabVIEW type, pass-by, description)
   - LabVIEW CLFN configuration steps (Calling convention, Parameter types, Array wiring)
   - Pre-allocate instructions for each output array (Initialize Array control → CLFN terminal)
   - Deployment path and deployment procedure
2. A VI Description (100 words max) for LabVIEW → File → VI Properties → Documentation
3. A one-paragraph note for the cRIO developer guide
4. A change log entry for version 1.0 release
```

---

## LabVIEW CLFN ↔ C Complete Type Mapping

### Scalar Inputs (Pass by Value)

| LabVIEW Type | C Type | CLFN Pass-By |
|---|---|---|
| DBL (double) | `double` | Value |
| SGL (single) | `float` | Value |
| I32 (integer) | `int32_t` | Value |
| U32 (unsigned) | `uint32_t` | Value |
| I16 | `int16_t` | Value |
| Boolean | `int32_t` (0 or 1) | Value |
| String | Not directly supported | Pass as `int32_t` enum index |

### Array Outputs (Pass as Array Data Pointer)

| LabVIEW Type | C Parameter | LabVIEW Pre-allocation |
|---|---|---|
| 1D Array of DBL | `double *out` | `Initialize Array [n] DBL` → wire to terminal |
| 1D Array of I32 | `int32_t *out` | `Initialize Array [n] I32` → wire to terminal |
| 1D Array of SGL | `float *out` | `Initialize Array [n] SGL` → wire to terminal |

> ⚠️ LabVIEW **must pre-allocate** the output array before calling the CLFN.
> The C function writes into the caller-provided buffer — it does not allocate.
> Use `Initialize Array` wired to the CLFN terminal, driven by a length control.

### Scalar Outputs (Pass as Pointer to Value)

| LabVIEW Usage | C Parameter | CLFN Pass-By |
|---|---|---|
| Single output DBL | `double *u_out` | Pointer to Value |
| Single output I32 | `int32_t *arm_out` | Pointer to Value |
| State round-trip (1 element) | `double *integrator` | Pointer to Value |

### What C CANNOT Easily Pass Back to LabVIEW

| Situation | Workaround |
|---|---|
| String output | Use int32_t status code; map to string in LabVIEW with Case Structure |
| Variable-length array | Use a fixed maximum length; include an out_len I32 parameter |
| Struct/record | Decompose into parallel scalar/array parameters |
| Multiple arrays of different types | Use separate pointer parameters for each |

---

## CLFN Configuration Reference

### Step-by-Step CLFN Dialog Setup

1. Drop a `Call Library Function Node` from Functions → Connectivity → Libraries & Executables
2. Double-click to open the configuration dialog
3. **Library name or path:** Enter the full path to the .so on the RT target, e.g.:
   `/home/lvuser/waveform_gen.so`
4. **Function name:** Enter the exact C function name (case-sensitive), e.g.:
   `generatewaveform`
5. **Calling convention:** `C` (not stdcall)
6. **Parameters tab:** Add each parameter in the exact order of the C function signature:
   - For scalar inputs: Type = Numeric, Data Type = DBL/I32, Pass = Value
   - For array outputs: Type = Array, Data Type = DBL/I32, Pass = Array Data Pointer
   - For scalar outputs (pointer): Type = Numeric, Data Type = DBL/I32, Pass = Pointer to Value
7. **Return type:** If function is `void`, set Return Type = Void

### Wiring Output Arrays in LabVIEW

```
For each array output parameter:
  1. Place an Initialize Array function on the block diagram
  2. Wire your length control (I32) to the "dimension size" input
  3. Wire a DBL (or appropriate type) constant to the "element" input  
  4. Wire the Initialize Array output to the CLFN array parameter terminal
  5. Wire the CLFN array parameter terminal output to your indicator
```

---

## Constraint Reference Card

| Constraint | Correct ✓ | Incorrect ✗ |
|---|---|---|
| EXPORT macro | `EXPORT void func(...)` | `void func(...)` (not visible from .so) |
| Calling convention | `C` in CLFN dialog | `stdcall` (causes crash on Linux) |
| Return type | `void` | `double[]` (not supported) |
| Array output | Caller allocates; C writes | `malloc` inside exported func and return pointer |
| Scalar output | `double *u_out; *u_out = val;` | `return val;` (CLFN expects void) |
| C standard | `-std=c99` | C++ features, `//` in C89 mode |
| Position-independent | `-fPIC` flag | No `-fPIC` (segfault when loaded as .so) |
| NULL guard | `if (!ptr || n<=0) return;` | Assume pointer is valid |
| Smoke test | `#ifdef FUNCNAME_SMOKE_TEST` | No test; test only in LabVIEW |
| Parameter order | **Frozen once released** | Reorder after wiring (breaks all VIs) |
| Random number | Custom LCG on RT | `rand()` (RT stdlib issues) |
| Memory in audio | No malloc per sample | `malloc(n*sizeof(double))` per call |
| State persistence | In/out double* array | `static double state;` (survives restarts) |
| Pre-integration | `make test` must pass | Deploy .so without smoke test |

---

## Pre-Integration Testing Protocol

**Always do this before deploying a .so to cRIO or wiring into a CLFN:**

```bash
# Step 1: Build and run smoke test on host (not on cRIO)
make test
# Expected output: all PASS lines, then "OVERALL: PASS"
# If ANY test prints FAIL, fix it before deploying.

# Step 2: Build the .so (cross-compile for NI Linux RT)
make all
# Expected: produces waveform_gen.so (or your .so name) without errors

# Step 3: Verify symbols are exported correctly
nm -D waveform_gen.so | grep " T "
# Your function name must appear as a "T" (text/exported) symbol

# Step 4: Copy to cRIO
sftp admin@192.168.1.10
> put waveform_gen.so /home/lvuser/
> quit

# Step 5: Only if all above pass — configure and wire in LabVIEW CLFN
```

> **Why this matters:** When LabVIEW loads a broken .so, error messages like "Error 1097"
> or "shared library not found" do not identify which function failed or why.
> A standalone smoke test failure is 10× faster to debug than a failure inside a VI.

---

## Parameter Order Lock Policy

Once a CLFN has been wired into a **released or shared LabVIEW VI**, the function parameter
order is **frozen**. LabVIEW CLFN wires parameters **by position** in the configuration dialog.

**Rules:**
- Never remove, insert, or reorder parameters in a released function without:
  1. Creating a new function with a new name (e.g., `generatewaveform_v2`)
  2. Updating all VIs that call the old function
  3. Re-deploying the new .so
  4. Incrementing the version comment at the top of the .c file
- Adding a new parameter at the **end** is acceptable if all existing callers are updated
- Document all changes in a `CHANGELOG` section at the top of the .c file

**Signal to AI:**
> "This function is released. Do NOT change the parameter order. If new parameters are
> needed, add them at the END. If you must restructure, create a new function with a
> `_v2` suffix and document the terminal mapping changes."

---

## Git / SVN Workflow (Optional)

### Git Workflow for C/.so Libraries

```bash
# Feature branch for new C function
git checkout -b feature/add-pid-step-so

# Test standalone first (on host, not cRIO)
make test
# Must print OVERALL: PASS

# Build .so
make all

# Commit source and .so binary
git add c/pid_step.c rt-so/pid_step.so
git commit -m "feat: add pid_step CLFN for DO control loop"

# Tag when releasing to LabVIEW integration
git tag v2.0.0-pid-step
git push origin feature/add-pid-step-so
```

### .gitignore Recommendations
```
*.o
*_test
# Optionally track .so if binary compatibility is important for reproducibility:
# rt-so/*.so  ← remove this line to track binaries
```

### Using the PowerShell Build Script
```powershell
# Build all .so files, then optionally commit binaries to Git
.\scripts\build_rt_sos.ps1 -RepoRoot "C:\Users\Public\Documents\GitHub\LV_Py_101" -GitCommit -CommitMessage "chore: rebuild RT .so binaries after drum_synth update"
```

> **Never commit a .c file to version control until `make test` passes.**
> Consider tracking `.so` binaries in Git only for deployment reproducibility —
> binary blobs can grow the repo; use Git LFS if .so files exceed a few MB.

---

## Waveform / Audio Debugging Checklist

| Symptom | Likely Cause | Fix |
|---|---|---|
| Output array all zeros | NULL not caught; wrong array pre-allocation size | Add NULL guard; verify Initialize Array size matches length_pts |
| Error 1097: library not found | Wrong path, or .so compiled for wrong architecture | Verify path on cRIO; check `file waveform_gen.so` shows x86-64 ELF |
| Segfault / Error 7 | NULL pointer dereference | Add `if (!out || n<=0) return;` guard |
| No sound output | Peak amplitude near zero | Check amp input is wired; verify EXPORT symbol with `nm -D` |
| Wrong pitch | Phase substitution instead of accumulation | Use `phase += 2*M_PI*f*dt` per sample |
| Distorted audio | No normalization after synthesis | Call `normalize(out, n)` after synthesis |
| Drum hits all sound like kick | freq_to_drum_id not applied | Apply freq_to_drum_id before passing drum_id to render_drum_hit |
| Melody learner always returns arm 0 | coeffs all zero; never updated | Wire like_dislike from user control; verify coeffs_out → shift register → coeffs_in |
| PID output saturated | Anti-windup not implemented | Clamp integrator to [out_min, out_max] each step |
| CLFN crash after redeployment | Old .so still loaded | Restart LabVIEW RT engine after .so update |
| Symbol not found by CLFN | Missing EXPORT or name mangling | Verify `nm -D lib.so | grep " T "` shows your function |

---

## Smoke Test Pattern Reference

Every exported function in this project uses the `#ifdef FUNCNAME_SMOKE_TEST` pattern.

```c
/* ── Smoke test (excluded from .so, only compiled as standalone executable) ── */
#ifdef WAVEFORM_SMOKE_TEST
#include <stdio.h>
#include <stdlib.h>

static int smoke(const char *name, /* ...test parameters... */, double expected_peak) {
    double *buf = (double *)malloc(n * sizeof(double));
    generatewaveform(/* args */);

    double peak = 0.0;
    for (int i = 0; i < n; i++) {
        double v = fabs(buf[i]);
        if (v > peak) peak = v;
    }
    free(buf);

    int ok = peak > expected_peak * 0.5;
    printf("%s: peak=%.4f  expected>%.4f  %s\n", name, peak, expected_peak*0.5, ok?"PASS":"FAIL");
    return ok;
}

int main(void) {
    int all = 1;
    all &= smoke("test_case_1", /* args */, 1.5);
    all &= smoke("test_case_2", /* args */, 0.5);
    all &= smoke("test_case_3", /* args */, 0.8);
    printf("OVERALL: %s\n", all ? "PASS" : "FAIL");
    return all ? 0 : 1;
}
#endif
```

**Build and run smoke test:**
```bash
# On host (not cRIO):
gcc -O2 -std=c99 -DWAVEFORM_SMOKE_TEST -o waveform_gen_test waveform_gen.c -lm
./waveform_gen_test
```

**Build .so for NI Linux RT:**
```bash
x86_64-linux-gnu-gcc -O2 -shared -fPIC -std=c99 -D_GNU_SOURCE -o waveform_gen.so waveform_gen.c -lm
```

---

## Quick Error Lookup

| LV Error / Symptom | Meaning | Fix |
|---|---|---|
| Error 1097 | Shared library failed to load | Check path; verify .so is x86-64 ELF; check file permissions on cRIO |
| Error 1098 | Function not found in library | Verify function name is exact; check `nm -D lib.so` exports |
| Segfault / Error 7 | NULL pointer or out-of-bounds write | Add NULL and size guards; verify Initialize Array size |
| All outputs zero | EXPORT missing; wrong calling convention | Add EXPORT macro; set CLFN to C calling convention |
| Sounds wrong / no audio | Amplitude near zero; wrong terminal order | Verify amp terminal is wired to parameter 1; check CLFN parameter order |
| CLFN config dialog empty | .so not found at path | Deploy .so to cRIO first; check path string in CLFN dialog |
| Works in Windows, fails on cRIO | Wrong architecture | Cross-compile with x86_64-linux-gnu-gcc; confirm with `file lib.so` |
| Crash after VI restart | Static state from previous run | Replace static variables with in/out pointer parameters |
| PID not responding to gain changes | Gains wired as constants | Wire Kp/Ki/Kd from front panel DBL controls, not constants |
| UCB1 resets on restart | Coefficients not saved | Save coeffs_out to CSV on cRIO at VI shutdown |

---

## CLFN vs Python Node — When to Choose Which

| Factor | Python Node | C CLFN (.so) |
|---|---|---|
| **Development speed** | Fast — AI writes Python quickly | Slower — requires C, cross-compile, deploy |
| **Runtime performance** | Moderate (Python overhead) | Fast (near-native C, minimal overhead) |
| **Hard real-time loop** | Not suitable | Suitable (no GIL, no garbage collection) |
| **Available on cRIO RT** | Yes (NI Linux RT Python) | Yes (any .so) |
| **numpy / scipy** | Available (install via pip) | Not available — use math.h |
| **State management** | list[float] in/out via shift register | double* in/out via pointer params |
| **Audio synthesis** | Works but slower at sample rate | Preferred for 44100 Hz loops |
| **AI learning loops** | Works; easy to modify | Works; better for RT-deployed learning |
| **Debugging** | `python file.py` standalone | `make test` → gcc smoke test |
| **Parameter order change** | Never reorder after release | Never reorder after release |
| **Best for** | Prototyping, AI models, data processing | Audio, control loops, real-time computation |

---

## References

- NI CLFN documentation: https://www.ni.com/docs/en-US/bundle/labview/page/lvhowto/using_clfn.html
- NI Linux RT cross-compilation: https://www.ni.com/docs/en-US/bundle/ni-linux-real-time-developers-guide/
- LV_Py_101 GitHub Repository: https://github.com/zach-olson-cyth/LV_Py_101
  - `waveform_gen.c`: minimal CLFN waveform generator pattern
  - `c/piano_synth.c`: ADSR + additive synthesis pattern
  - `c/drum_synth.c`: drum synthesis + LCG noise + bridge function pattern
  - `c/melody_learn_v3.c`: UCB1 AI learning loop with coeffs state pattern
  - `Makefile`: cross-compile and smoke test build targets
  - `scripts/build_rt_sos.ps1`: PowerShell cross-build with optional Git commit
- NI Community: https://forums.ni.com/t5/LabVIEW/bd-p/170
- LAVA Forums: https://lavag.org/
